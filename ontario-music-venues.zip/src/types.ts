export interface Venue {
  name: string;
  address: string;
  capacity: number;
}
